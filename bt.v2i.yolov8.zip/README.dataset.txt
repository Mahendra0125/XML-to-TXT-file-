# bt > 2022-11-03 10:09pm
https://universe.roboflow.com/sid-klalj/bt-sadni

Provided by a Roboflow user
License: CC BY 4.0

